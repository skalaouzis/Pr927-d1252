class AddPositiceImageToPosts < ActiveRecord::Migration
  def change
    add_column :posts, :positive_images, :string
  end
end
