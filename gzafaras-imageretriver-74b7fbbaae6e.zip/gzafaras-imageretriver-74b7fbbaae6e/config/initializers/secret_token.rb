# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Imageretriver::Application.config.secret_key_base = 'c800e73503ce675c861cc6e83069b40373168d4bd2e04079d5df68b393b44f7dbc2fc33cda656571763b558af70fc702057cbd8794a7af378a77520e2b542b8d'
