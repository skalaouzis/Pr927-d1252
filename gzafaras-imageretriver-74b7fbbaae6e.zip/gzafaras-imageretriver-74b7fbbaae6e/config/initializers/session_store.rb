# Be sure to restart your server when you modify this file.

Imageretriver::Application.config.session_store :cookie_store, key: '_imageretriver_session'
